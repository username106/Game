using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class menu_main : MonoBehaviour
{
    public static bool eeasy =false;
    public static bool medium=false ;
    public static bool hard =false;
    public void Showcase_game()
    {
        //SceneManager.LoadScene("Game");
        SceneManager.LoadScene("Game");
    }
    public void Fight_game()
    {
        //SceneManager.LoadScene("Game");
        SceneManager.LoadScene("batle_test");
    }
    public void Play_game_E()
    {
        //SceneManager.LoadScene("Game");
        SceneManager.LoadScene("level_gen");
        Generator3D.easy = true;
        Generator3D.medium = false;
        Generator3D.hard = false;
        //eeasy=true;
        //medium = false;
        //hard = false;
    }
    public void Play_game_M()
    {
        //SceneManager.LoadScene("Game");
        SceneManager.LoadScene("level_gen");
        Generator3D.easy = false;
        Generator3D.medium = true;
        Generator3D.hard = false;
        //eeasy = false;
        //medium = true;
        //hard = false;
    }
    public void Play_game_H()
    {
        //SceneManager.LoadScene("Game");
        SceneManager.LoadScene("level_gen");
        Generator3D.easy = false;
        Generator3D.medium = false;
        Generator3D.hard = true;
        //eeasy = false;
        //medium = false;
        //hard = true;
    }
    public void Quit_game()
    {
        //Debug.Log("EXIT!");
        Application.Quit();
    }
}
